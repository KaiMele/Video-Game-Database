USE group_fish_net;

-- Question 1: What game produced by Santa Monica Studio supports the highest number of players?
SELECT g.title AS 'Game Title', MAX(g.max_number_of_players) AS 'Number of Players'
FROM game g
JOIN developer d ON g.fk_game_developer_id_developer_developer_id = d.developer_id
WHERE d.developer_name = 'Santa Monica Studio'
GROUP BY g.title
ORDER BY MAX(g.max_number_of_players) DESC
LIMIT 1;

-- Question 2: List three fantasy games released in May of 2009.
SELECT g.title AS 'Game Title', g.release_date AS 'Release Date', gen.genre_type AS 'Genre'
FROM game g
INNER JOIN game_genre gmre ON g.game_id = gmre.game_id
INNER JOIN genre gen ON gmre.genre_id = gen.genre_id
WHERE gen.genre_type = 'Fantasy' AND ((MONTH(g.release_date) = 05) AND (YEAR(g.release_date) = 2009))
LIMIT 3;

-- Question 3: How many games have a ‘Teen’ Rating?
SELECT COUNT(*) AS 'Number of Games'
FROM game
WHERE fk_game_esrb_rating_id_esrb_rating_esrb_rating_id = (
    SELECT esrb_rating_id
    FROM esrb_rating
    WHERE rating = 'Teen'
);

-- Question 4: List any games using Unreal Engine that you can play on PS5.
SELECT g.title AS 'Game Title', ge.game_engine AS 'Game Engine', p.name AS 'Platform'
FROM game g
JOIN game_engine ge ON g.fk_game_game_engine_id_game_engine_engine_id = ge.game_engine_id
JOIN game_platform gp ON g.game_id = gp.game_id
JOIN platform p ON gp.platform_id = p.platform_id
WHERE ge.game_engine = 'UNREAL' AND p.name IN ('PS5');

-- Question 5: What are all the games that FromSoftware developed?
SELECT g.title AS 'Game Title', d.developer_name AS 'Developer'
FROM game g 
INNER JOIN developer d ON g.fk_game_developer_id_developer_developer_id = d.developer_id
WHERE d.developer_name = 'FromSoftware';

-- Question 6: Show every game that Matthew Mercer voice acted in.
SELECT g.title AS 'Game Title', a.name AS 'Actor'
FROM game g
JOIN game_actor ga ON g.game_id = ga.game_id
JOIN actor a ON ga.actor_id = a.actor_id
WHERE a.name = 'Matthew Mercer';

-- Question 7: What are the system requirements for games that feature music composed by Hans Zimmer?
SELECT g.title AS 'Game Title', r.req_desc AS 'Requirement', s.composer AS 'Composer'
FROM game g 
INNER JOIN soundtrack s ON g.fk_game_soundtrack_id_soundtrack_soundtrack_id = s.soundtrack_id
INNER JOIN game_requirements gr ON g.game_id = gr.game_id
INNER JOIN requirements r ON gr.req_id = r.req_id
WHERE s.composer = 'Hans Zimmer';

-- Question 8: List the publishers that have released at least three games with an ESRB rating of ‘Mature’.
SELECT p.publisher_name AS 'Publisher', e.rating AS 'ESRB_Rating'
FROM publisher p
LEFT JOIN game g ON p.publisher_id = g.fk_game_publisher_id_publisher_publisher_id
JOIN esrb_rating e ON g.fk_game_esrb_rating_id_esrb_rating_esrb_rating_id = e.esrb_rating_id
WHERE e.rating = 'Mature 17+'
GROUP BY p.publisher_id
HAVING COUNT(g.game_id) >= 3;

-- Question 9: How many games are offered in Spanish?
SELECT COUNT(DISTINCT game_id) AS 'Number of Spanish Games'
FROM game_languages
WHERE lang_id IN (
    SELECT lang_id FROM languages WHERE lang_name = 'Spanish'
);

-- Question 10: Which games were published by Nintendo?
SELECT g.title AS 'Game Title', p.publisher_name AS 'Publisher'
FROM game g
JOIN publisher p ON g.fk_game_publisher_id_publisher_publisher_id = p.publisher_id
WHERE p.publisher_name = 'Nintendo';


-- TRANSACTION -- 
START TRANSACTION;

INSERT INTO game (game_id, title, max_number_of_players, release_date, description, 
fk_game_game_engine_id_game_engine_engine_id, 
fk_game_esrb_rating_id_esrb_rating_esrb_rating_id, 
fk_game_soundtrack_id_soundtrack_soundtrack_id, 
fk_game_developer_id_developer_developer_id, 
fk_game_publisher_id_publisher_publisher_id)
VALUES 
(11, 'Undertale', 1, '2015-09-15', 'Undertale is a 2015 2D role-playing video game created by American indie developer Toby Fox. The player controls a child named Frisk who has fallen into the Underground: a large, secluded region under the surface of the Earth, separated by a magical barrier.' , 7, 3, 7, 3, 2);


UPDATE developer
SET foundation_date = '1990-01-01'
WHERE developer_id = 1;


COMMIT;

-- BONUS //
DROP PROCEDURE IF EXISTS InsertNewGame;
DELIMITER //

CREATE PROCEDURE InsertNewGame(
    IN p_title VARCHAR(100),
    IN p_max_players INT,
    IN p_release_date DATE,
    IN p_description TEXT,
    IN p_fk_game_game_engine_id_game_engine_engine_id INT,
    IN p_fk_game_esrb_rating_id_esrb_rating_esrb_rating_id INT,
    IN p_fk_game_soundtrack_id_soundtrack_soundtrack_i INT,
    IN p_fk_game_developer_id_developer_developer_id INT,
    IN p_fk_game_publisher_id_publisher_publisher_id INT,
    OUT p_game_id INT
)
BEGIN
DECLARE v_game_id INT;

   
    START TRANSACTION;

  
    INSERT INTO game (title, max_number_of_players, release_date, description, 
    fk_game_game_engine_id_game_engine_engine_id,
    fk_game_esrb_rating_id_esrb_rating_esrb_rating_id, 
    fk_game_soundtrack_id_soundtrack_soundtrack_id, 
    fk_game_developer_id_developer_developer_id, 
    fk_game_publisher_id_publisher_publisher_id)
    VALUES (p_title, p_max_players, p_release_date, p_description, 
    p_fk_game_game_engine_id_game_engine_engine_id, 
    p_fk_game_esrb_rating_id_esrb_rating_esrb_rating_id, 
    p_fk_game_soundtrack_id_soundtrack_soundtrack_id, 
    p_fk_game_developer_id_developer_developer_id, 
    p_fk_game_publisher_id_publisher_publisher_id);


    SELECT LAST_INSERT_ID() INTO v_game_id;

   
    IF v_game_id IS NOT NULL THEN
       
        SET p_game_id = v_game_id;
        
        COMMIT;
    ELSE
        
        ROLLBACK;
    END IF;
END //

DELIMITER ;

CALL InsertNewGame(
    12,
   'Journey',
    4,
    '2012-03-13',
    'Journey is an indie adventure game developed by Thatgamecompany, published by Sony Computer Entertainment, and directed by Jenova Chen. It was released for the PlayStation 3 via PlayStation Network in March 2012 and ported to PlayStation 4 in July 2015.',
    3,
    1,
    8,
    3,
    2
);