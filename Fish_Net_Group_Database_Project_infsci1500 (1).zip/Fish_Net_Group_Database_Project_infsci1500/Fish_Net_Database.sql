USE group_fish_net;

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS game,genre,gameplay,game_engine,esrb_rating,platform,soundtrack,actor,developer,
publisher,contributor,requirements,languages, game_platform, game_actor, game_contributor, game_genre, game_gameplay,
game_languages, game_requirements;

CREATE TABLE game (
    game_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    max_number_of_players INT NOT NULL,
    release_date DATE NOT NULL,
    description TEXT NOT NULL,
    fk_game_game_engine_id_game_engine_engine_id INT,
    fk_game_esrb_rating_id_esrb_rating_esrb_rating_id INT NOT NULL,
    fk_game_soundtrack_id_soundtrack_soundtrack_id INT NOT NULL,
    fk_game_developer_id_developer_developer_id INT NOT NULL,
    fk_game_publisher_id_publisher_publisher_id INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE genre (
    genre_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    genre_type VARCHAR(100) NOT NULL
)ENGINE=InnoDB;

CREATE TABLE gameplay (
    gameplay_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    gameplay_type VARCHAR(100) NOT NULL
)ENGINE=InnoDB;

CREATE TABLE game_engine (
    game_engine_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    game_engine VARCHAR(100) NOT NULL
);

CREATE TABLE esrb_rating (
    esrb_rating_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    rating VARCHAR(50) NOT NULL,
    rating_desc TEXT NOT NULL
);

CREATE TABLE platform (
    platform_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    release_date DATE NOT NULL,
    generation VARCHAR(50),
    manufacturer VARCHAR(100)
)ENGINE=InnoDB;

CREATE TABLE soundtrack (
    soundtrack_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    composer VARCHAR(100) NOT NULL,
    duration TIME,
    number_of_tracks INT,
    music_label VARCHAR(100),
    release_date DATE
)ENGINE=InnoDB;

CREATE TABLE actor (
    actor_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    game_character VARCHAR(100) NOT NULL
)ENGINE=InnoDB;

CREATE TABLE developer (
    developer_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    developer_name VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    company_type VARCHAR(100),
    ceo_name VARCHAR(100),
    foundation_date DATE
)ENGINE=InnoDB;

CREATE TABLE publisher (
    publisher_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    publisher_name VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    company_type VARCHAR(100),
    ceo_name VARCHAR(100),
    foundation_date DATE
)ENGINE=InnoDB;

CREATE TABLE contributor (
    contributor_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    contributor_name VARCHAR(100) NOT NULL,
    contributor_role VARCHAR(100) NOT NULL
)ENGINE=InnoDB;

CREATE TABLE requirements (
	req_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    req_desc TEXT NOT NULL
)ENGINE=InnoDB;

CREATE TABLE languages (
	lang_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    lang_name VARCHAR(50) NOT NULL
)ENGINE=InnoDB;


-- DATA INSERTS --

INSERT INTO game (game_id, title, max_number_of_players, release_date, description, 
fk_game_game_engine_id_game_engine_engine_id, 
fk_game_esrb_rating_id_esrb_rating_esrb_rating_id, 
fk_game_soundtrack_id_soundtrack_soundtrack_id, 
fk_game_developer_id_developer_developer_id, 
fk_game_publisher_id_publisher_publisher_id)
VALUES 
(1, 'Dark Souls', 4, '2009-05-22', "Dark Souls is a 2011 action role-playing game developed by FromSoftware and published by Namco Bandai Games. A spiritual successor to FromSoftware's Demon's Souls, the game is the first in the Dark Souls series.", 11, 4, 1, 1, 2),
(2, 'God of War Ragnarök', 1, '2022-11-09', "From Santa Monica Studio comes the sequel to the critically acclaimed God of War (2018). Fimbulwinter is well underway. Kratos and Atreus must journey to each of the Nine Realms in search of answers as Asgardian forces prepare for a prophesied battle that will end the world. Along the way they will explore stunning, mythical landscapes, and face fearsome enemies in the form of Norse gods and monsters. The threat of Ragnarök grows ever closer. Kratos and Atreus must choose between their own safety and the safety of the realms.", 5, 4, 2, 2, 2),
(3, 'Destiny 2', 6, '2009-05-06', "Destiny 2 is a free-to-play online first-person shooter video game developed by Bungie. It was originally released as a pay to play game in 2017 for PlayStation 4, Xbox One, and Windows.", 12, 3, 11, 11, 12),
(4, 'Super Mario Bros', 2, '1985-09-13', "Super Mario Bros. is a platform game developed and published in 1985 by Nintendo for the Famicom in Japan and for the Nintendo Entertainment System in North America. It is the successor to the 1983 arcade game Mario Bros. and the first game in the Super Mario series.", 7, 1, 5, 9, 3),
(5, 'The Last of Us', 1, '2017-12-05', "The Last of Us is an action-adventure video game series and media franchise created by Naughty Dog and published by Sony Interactive Entertainment. The series is set in a post-apocalyptic United States ravaged by cannibalistic humans infected by a mutated fungus in the genus Cordyceps.", 1, 4, 4, 4, 2), 
(6, "Baldur's Gate 3", 4, '2023-08-03', "Baldur's Gate 3 is a 2023 role-playing video game developed and published by Larian Studios. It is the third main installment to the Baldur's Gate series, based on the tabletop fantasy role-playing system of Dungeons & Dragons.", 5, 4, 12, 12, 13),
(7, 'Minecraft', 8, '2009-05-17', 'Minecraft is a 2011 sandbox game developed by Mojang Studios and originally released in 2009. The game was created by Markus "Notch" Persson in the Java programming language.', 3, 1, 3, 4, 5),
(8, 'Kingdom Hearts', 1, '2013-05-09', 'Kingdom Hearts is a series of action role-playing games created by Japanese game designers Tetsuya Nomura and Shinji Hashimoto, being developed and published by Square Enix. It is a collaboration between Square Enix and The Walt Disney Company, and is under the leadership of Nomura, a longtime Square Enix employee.', 1, 3, 6, 3, 2),
(9, 'Final Fantasy VII', 1, '1997-05-07', 'Final Fantasy VII is a 1997 role-playing video game developed by Square for the PlayStation console and the seventh main installment in the Final Fantasy series.', 1, 3, 10, 13, 7),
(10, 'Skyrim', 1, '2011-11-11', 'The Elder Scrolls V: Skyrim is a 2011 action role-playing game developed by Bethesda Game Studios and published by Bethesda Softworks.', 11, 4, 9, 7, 2);

INSERT INTO genre (genre_id, genre_type)
VALUES 
(1, 'Fantasy'), -- game_id 1
(2, 'Action-adventure'), -- game_id 2
(3, 'Horror'),
(4, 'Mystery'),
(5, 'Cyberpunk'), 
(6, 'Educational'),
(7, 'Sports'), 
(8, 'War'), 
(9, 'Western'),
(10, 'Comedy'), 
(11, 'Superhero'), 
(12, 'Science fiction'), 
(13, 'Crime'), 
(14, 'Romance'), 
(15, 'Rhythm'), 
(16, 'Survival'), 
(17, 'Racing'), 
(18, 'Fighting'), 
(19, 'Anime');  

INSERT INTO gameplay (gameplay_id, gameplay_type)
VALUES 
(1, 'ARPG'), -- game_id 1
(2, 'Hack-and-slash'), -- game_id 2
(3, 'MMORPG'), 
(4, 'First-person shooter'), 
(5, 'Card'), 
(6, 'Platformer'), 
(7, 'Open-world'),
(8, 'Sandbox'),
(9, 'Battle royale'), 
(10, 'Third-person shooter'),
(11, 'Puzzle'),
(12, 'Single-player'), 
(13, 'Multiplayer'), 
(14, 'Cooperative (Co-Op)'), 
(15, 'PvP'), 
(16, 'Turn-based'), 
(17, 'Simulation'), 
(18, 'RPG'), 
(19, 'Rogue-like'), 
(20, 'Tower defense'); 

INSERT INTO game_engine (game_engine_id, game_engine)
VALUES 
(1, 'UNREAL'), 
(2, 'Phyre'), 
(3, 'Unity'), 
(4, 'Godot Engine'),
(5, 'Divinity'),
(6, 'Anvil'), 
(7, 'RPG Maker'),
(8, 'Twine'),
(9, 'Source'), 
(10, 'Phaser'),
(11, 'Havok'),
(12, 'Tiger');

INSERT INTO esrb_rating (esrb_rating_id, rating, rating_desc)
VALUES 
(1, 'Everyone', 'Content is generally suitable for all ages. May contain minimal cartoon, fantasy, or mild violence and/or infrequent use of mild language'),
(2, 'Everyone 10+', 'Content is generally suitable for ages 10 an up. May contain more cartoon, fantasy, or mild violence, mild language and/or minimal suggestive themes.'),
(3, 'Teen', 'Content is generally suitable for ages 13 and up. May contain violence, suggestive themes, crude humor, minimal bood, simulated gambling and/or infrequent use of strong language'),
(4, 'Mature 17+', 'Content is generally suitable for ages 17 and up. May contain intense violence, blood and gore, sexual content and/or strong language.'),
(5, 'Adults Only 18+', 'Content suitable only for adults ages 18 and up. May include prolonged scenes of intense violence, graphic sexual content, and/or gambling with real currency.'),
(6, 'Rating Pending', "Not yet assigned a final ESRB rating. Appears only in advertising, marketing, and promotional materials related to a physical (e.g., boxed) video game that is expected to carry an ESRB rating, and should be replaced by a game's rating once it has been assigned."),
(7, 'Rating Pending - Likely Mature 17+', "Not yet assigned to a final ESRB rating but anticipated to be rated Mature 17+. Appears only in advertising, marketing, and promotional materials related to a physical (e.g., boxed) video game that is expected to carry on ESRB rating, and should be replaced by a game's rating once it has been assigned."),
(8, 'Cat', "Content is generally suitable for all felines. May contain violent meowing, biscuit-making, and debauchery or include bastard-like behavior not suitable for all ages."),
(9, 'Wrestler', 'Content is suitable only for professional wrestlers with a history of mauling, bone-breaking, tax evasion, and part-time acting. May include graphic imagery of the Rock. Contains no imagery of John Cena'),
(10, 'Alien', 'Content is suitable for all non-terrestrial life forms. May include prolonged scenes of cow-napping, alien probing, and world domination, suggestive crop circles, and graphic UFOs');

INSERT INTO platform (platform_id, name, release_date, generation, manufacturer)
VALUES 
(1, 'Xbox', '2001-11-15', 6, 'Microsoft'), -- game_id 1
(2, 'PS4', '2013-11-15', 8, 'Sony Electronics'), -- game_id 2
(3, 'PS5', '2020-11-12', 9, 'Sony'), -- game_id 2; 
(4, 'Xbox 360', '2005-11-22', 7, 'Microsoft'),
(5, 'Xbox One', '2013-11-22', 8, 'Microsoft'),
(6, 'Xbox Series X', '2020-11-10', 9, 'Microsoft'),
(7, 'Nintendo Switch', '2017-03-03', 8, 'Nintendo'),
(8, 'PC', '1974-01-07', 1, 'N/A'),
(9, 'Nintendo Wii', '2006-11-19', 7, 'Nintendo'),
(10, 'Nintendo DS', '2004-11-21', 7, 'Nintendo');

INSERT INTO soundtrack (soundtrack_id, title, composer, duration, number_of_tracks, music_label, release_date)
VALUES 
(1, 'Dark Souls Soundtrack', 'Motoi Sakuraba', '00:01:29', 29, 'Bandai Namco Entertainment Inc.', '2011-09-22'),
(2, 'God of War Ragnarök (Original Soundtrack)', 'Bear McCreary', '00:01:59', 28, 'Sony Music Entertainment', '2022-11-09'),
(3, 'Minecraft OST', 'Hans Zimmer', '00:48:17', 11, 'C4-18', '2010-03-17'),
(4, 'Music from The Last of Us', 'Gustavo Santaolalla', '00:53:35', 18, 'Sony Music Entertainment', '2017-12-05'),
(5, 'Music from Super Mario Bros', 'Hans Zimmer', '00:37:19', 9, 'Wii Music', '2009-01-31'), 
(6, 'Kingdom Hearts OST', 'Yoko Shimomura', '00:02:18', 25, 'Scarlet Moon Records', '2013-05-09'),
(7, 'Undertale OST', 'Hans Zimmer', '0:01:42', 16, 'Papyrus Studios', '2015-04-23'),
(8, 'Journey (Original Soundtrack)', 'Austin Wintory', '00:01:12', 14, 'Materia Collective', '2013-07-22'),
(9, 'Music from Elder Scrolls and Skyrim', 'Jeremy Soule', '00:02:37', 35, 'Materia Collective', '2020-06-25'),
(10, 'Final Fantasy VII OST', 'Nobuo Uematsu', '00:01:59', 27, 'Bandai Namco Entertainment Inc.', '2018-11-01'),
(11, 'Destiny 2 OST', 'Michael Salvatori', '00:02:20', 44, 'Bungie', '2017-09-06'),
(12, "Baldur's Gate 3 OST", 'Borislav Slavov', '00:02:19', 52, 'Larian Studios', '2023-08-03');

INSERT INTO actor (actor_id, name, game_character)
VALUES 
(1, 'Miles Richardson', 'Siegmeyer'), -- game_id 1
(2, 'Christopher Judge', 'Kratos'),
(3, 'Matthew Mercer', 'Minsc'),
(4, 'Matthew Mercer', 'Cole Cassidy'),
(5, 'Matthew Mercer', 'Yusuke Kitagawa'),
(6, 'Troy Baker', 'Higgs Monaghan'),
(7, 'Troy Baker', 'Joel Miller'), 
(8, 'Mark Hamill', 'Joker'),
(9, 'Tara Strong', 'Cortana'), 
(10, 'David Hayter', 'Solid Snake'),
(11, 'Ashley Johnson', 'Ellie'),
(12, 'Norman Reedus', 'Sam Porter Bridges'),
(13, 'Jennifer Hale', 'Commander Shephard'),
(14, 'Charles Martinet', 'Mario'),
(15, 'Nolan North', 'Nathan Drake');

INSERT INTO developer (developer_id, developer_name, city, company_type, ceo_name, foundation_date)
VALUES 
(1, 'FromSoftware', 'Tokyo', 'Joint-Venture', 'Hidetaka Miyazaki', '1986-11-01'), -- game_id 1
(2, 'Santa Monica Studio', 'Santa Monica', 'Subsidiary', 'Allan Becker', '1999-01-01'), -- game_id 2
(3, 'Sony Interactive Entertainment Worldwide Studios', 'San Mateo', 'Division', 'Herman Hulst', '2005-09-01'),
(4, 'Naughty Dog', 'Santa Monica', 'Subsidiary', 'Neil Druckmann', '1984-07-05'),
(5, 'Rockstar Games', 'New York City', 'Subsidiary', 'Sam Houser', '1998-12-30'),
(6, 'BioWare', 'Alberta', 'Subsidiary', 'Gary McKay', '1995-02-01'),
(7, 'Bethesda Game Studios', 'Rockville', 'Division', 'Angela Browder', '2001-10-18'),
(8, 'Valve Corporation', 'Bellevue', 'Private', 'Gabe Newell', '1996-08-24'),
(9, 'Nintendo', 'Tokyo', 'Public', 'Shuntaro Furukawa', '1889-09-23'),
(10, 'Riot Games', 'Los Angeles', 'Subsidiary', 'Dylan Jadeja', '2006-09-29'),
(11, 'Bungie', 'Bellevue', 'Public', 'Pete Parsons', '1991-05-17'),
(12, 'Larian Studios', 'Ghent', 'Private', 'Swen Vincke', '1996-06-22'),
(13, 'Square Enix', 'Shinjuku', 'Public', 'Takashi Kiryu', '2003-04-01');

INSERT INTO publisher (publisher_id, publisher_name, city, company_type, ceo_name, foundation_date)
VALUES 
(1, 'Bandai Namco', 'Tokyo', 'Subsidiary', 'Genichi Ito', '2006-3-31'), -- game_id 1
(2, 'Sony Interactive Entertainment', 'San Mateo', 'Subsidiary', 'Hiroki Totoki', '2016-04-01'), -- game_id 2
(3, 'Nintendo', 'Tokyo', 'Public', 'Shuntaro Furukawa', '1889-09-23'),
(4, 'Electronic Arts', 'Redwood City', 'Public', 'Andrew Wilson', '1982-05-27'),
(5, 'Ubisoft', 'Saint-Mandé', 'Public', 'Yves Guillemot', '1986-03-26'), 
(6, 'Activision Blizzard', 'Santa Monica', 'Subsidiary', 'Jack Black', '2008-07-09'),
(7, 'Square Enix', 'Shinjuku', 'Public', 'Takashi Kiryu', '2003-04-01'),
(8, 'Capcom', 'Osaka', 'Public', 'Kenzo Tsujimoto', '1979-05-29'),
(9, 'Bethesda Softworks LLC', 'Rockville', 'Subsidiary', 'Christopher Weaver', '1986-06-28'),
(10, 'Sega', 'Tokyo', 'Subsidiary', 'Haruki Satomi', '1960-06-03'),
(11, 'CD Projekt', 'Warsaw', 'Public', 'Michał Nowakowski', '1994-05-13'),
(12, 'Bungie', 'Bellevue', 'Public', 'Pete Parsons', '1991-05-17'),
(13, 'Larian Studios', 'Ghent', 'Private', 'Swen Vincke', '1996-06-22');

INSERT INTO contributor (contributor_id, contributor_name, contributor_role)
VALUES 
(1, 'Hidetaka Miyazaki', 'Director'), 
(2, 'Eric Williams', 'Director'), 
(3, 'Cory Barlog', 'Director'),
(4, 'Chad Cox', 'Producer'), 
(5, 'Jason McDonald', 'Designer'), 
(6, 'Josh Hobson', 'Programmer'), 
(7, 'Rafael Grassetti', 'Artist'), 
(8, 'Matt Sophos', 'Writer'), 
(9, 'Richard Zangrande Gaubert', 'Writer'),
(10, 'Sofia Martinez', 'Artist'), 
(11, 'Lila Nguyen', 'Programmer'), 
(12, 'Aisha Rahman', 'Designer'), 
(13, 'Priya Kapoor', 'Director'), 
(14, 'Mei Chen', 'Producer'), 
(15, 'Akira Patel', 'Writer'), 
(16, 'Hideo Kojima', 'Director'), 
(17, 'Todd Howard', 'Director'), 
(18, 'Junichi Masuda', 'Director'), 
(19, 'Neil Druckmann', 'Director'),
(20, 'Amy Hennig', 'Producer'),
(21, 'Shigeru Miyamoto', 'Programmer'),
(22, 'Eli Smith', 'Artist'),
(23, 'Jasmine Tokohoma', 'Writer'),
(24, 'Raymond Firth', 'Designer'),
(25, 'Olaf Wright', 'Artist'); 

INSERT INTO requirements (req_id, req_desc)
VALUES 
(1, 'DuelSense Wireless PS5 Controller'),
(2, 'Gaming Keyboard'),
(3, 'Wii Remote'),
(4, 'Nintendo Switch Joy-Con'), 
(5, 'Xbox Controller'), 
(6, 'PC Gamepad'),
(7, 'Arcade Stick'), 
(8, 'SNES Controller'), 
(9, 'Smartphone'), 
(10, 'Rock Band Drums'), 
(11, 'Rock Band Guitar'),
(12, 'Retro-Bit Tribute64'),
(13, 'PowerA Enhanced Wired Controller'),
(14, '8BitDo SN30 Pro+'),
(15, 'Razer Wolverine Ultimate');

INSERT INTO languages (lang_id, lang_name)
VALUES
(1, 'English'),
(2, 'Japanese'),
(3, 'Spanish'),
(4, 'French'),
(5, 'German'),
(6, 'Arabic'),
(7, 'Greek'),
(8, 'Italian'), 
(9, 'Polish'),
(10, 'Portuguese'), 
(11, 'Russian'),
(12, 'Chinese'),
(13, 'Korean');

-- ALTER TABLE STATEMENTS -- 

SET FOREIGN_KEY_CHECKS=1;

ALTER TABLE game
ADD CONSTRAINT fk_game_engine_game_engine_id_game_game_engine_id
FOREIGN KEY (fk_game_game_engine_id_game_engine_engine_id)
REFERENCES game_engine(game_engine_id)
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE game
ADD CONSTRAINT fk_esrb_rating_esrb_rating_id_game_esrb_rating_id
FOREIGN KEY (fk_game_esrb_rating_id_esrb_rating_esrb_rating_id)
REFERENCES esrb_rating(esrb_rating_id)
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE game
ADD CONSTRAINT fk_soundtrack_soundtrack_id_game_soundtrack_id
FOREIGN KEY (fk_game_soundtrack_id_soundtrack_soundtrack_id)
REFERENCES soundtrack(soundtrack_id)
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE game
ADD CONSTRAINT fk_developer_developer_id_game_developer_id
FOREIGN KEY (fk_game_developer_id_developer_developer_id)
REFERENCES developer(developer_id)
ON DELETE CASCADE
ON UPDATE CASCADE;

ALTER TABLE game
ADD CONSTRAINT fk_game_publisher_id_publisher_publisher_id
FOREIGN KEY (fk_game_publisher_id_publisher_publisher_id)
REFERENCES publisher(publisher_id)
ON DELETE CASCADE
ON UPDATE CASCADE;

-- JUNCTION TABLES -- 

CREATE TABLE game_platform (
    game_id INT NOT NULL,
    platform_id INT NOT NULL,
    PRIMARY KEY (game_id, platform_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (platform_id) REFERENCES platform(platform_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
)ENGINE=InnoDB;

INSERT INTO game_platform (game_id, platform_id)
VALUES
(1, 6),
(2, 8),
(3, 5),
(4, 2),
(5, 3),
(6, 10),
(7, 9),
(8, 4),
(9, 3),
(10, 7);

CREATE TABLE game_actor (
    game_id INT NOT NULL,
    actor_id INT NOT NULL,
    PRIMARY KEY (game_id, actor_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (actor_id) REFERENCES actor(actor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO game_actor (game_id, actor_id)
VALUES
(1, 7),
(2, 12),
(3, 3),
(4, 9),
(5, 5),
(6, 14),
(7, 2),
(8, 10),
(9, 8),
(10, 6);

CREATE TABLE game_contributor (
    game_id INT NOT NULL,
    contributor_id INT NOT NULL,
    PRIMARY KEY (game_id, contributor_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (contributor_id) REFERENCES contributor(contributor_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO game_contributor (game_id, contributor_id)
VALUES
(1, 17),
(2, 9),
(3, 22),
(4, 5),
(5, 13),
(6, 20),
(7, 8),
(8, 3),
(9, 24),
(10, 11);

CREATE TABLE game_genre (
    game_id INT NOT NULL,
    genre_id INT NOT NULL,
    PRIMARY KEY (game_id, genre_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (genre_id) REFERENCES genre(genre_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO game_genre (game_id, genre_id)
VALUES
(1, 1),
(2, 14),
(3, 1),
(4, 7),
(5, 5),
(6, 3),
(7, 1),
(8, 12),
(9, 18),
(10, 9);

CREATE TABLE game_gameplay (
    game_id INT NOT NULL,
    gameplay_id INT NOT NULL,
    PRIMARY KEY (game_id, gameplay_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (gameplay_id) REFERENCES gameplay(gameplay_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO game_gameplay (game_id, gameplay_id)
VALUES
(1, 16),
(2, 5),
(3, 4),
(4, 10),
(5, 3),
(6, 19),
(7, 8),
(8, 4),
(9, 4),
(10, 14);

CREATE TABLE game_requirements (
    game_id INT NOT NULL,
    req_id INT NOT NULL,
    PRIMARY KEY (game_id, req_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (req_id) REFERENCES requirements(req_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO game_requirements (game_id, req_id)
VALUES
(1, 8),
(2, 12),
(3, 5),
(4, 3),
(5, 10),
(6, 14),
(7, 2),
(8, 9),
(9, 6),
(10, 13);

CREATE TABLE game_languages (
    game_id INT NOT NULL,
    lang_id INT NOT NULL,
    PRIMARY KEY (game_id, lang_id),
    FOREIGN KEY (game_id) REFERENCES game(game_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
    FOREIGN KEY (lang_id) REFERENCES languages(lang_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

INSERT INTO game_languages (game_id, lang_id)
VALUES
(1, 7),
(2, 12),
(3, 3),
(4, 9),
(5, 5),
(6, 11),
(7, 2),
(8, 3),
(9, 10),
(10, 8);

